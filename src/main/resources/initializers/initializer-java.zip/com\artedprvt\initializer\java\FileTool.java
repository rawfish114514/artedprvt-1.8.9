package com.artedprvt.initializer.java;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileTool {
    public static List<File> getAllFile(File file) {
        List<File> files = new ArrayList<>();
        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                files.addAll(getAllFile(f));
            }
        } else {
            files.add(file);
        }
        return files;
    }

    public static String relativize(File base, File full) {
        return base.toPath().relativize(full.toPath()).toString().replace(File.separatorChar, '/');
    }
}