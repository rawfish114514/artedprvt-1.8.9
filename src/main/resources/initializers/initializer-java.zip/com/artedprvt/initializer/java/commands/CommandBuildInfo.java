package com.artedprvt.initializer.java.commands;

import com.artedprvt.std.cli.CompleteInterface;
import com.artedprvt.std.cli.FormatHandler;
import com.artedprvt.std.cli.FormatInterface;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.InfoInterface;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.std.cli.util.Literals;
import com.artedprvt.work.anno.Command;
import com.artedprvt.initializer.java.Main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.List;

@Command
public class CommandBuildInfo implements ProcessInterface, CompleteInterface, FormatInterface, InfoInterface {
    public CommandBuildInfo() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        if (args.size() >= 7) {
            String name = args.get(0);
            String id = args.get(1);
            String version = args.get(2);
            String mcversion = args.get(3);
            String main = args.get(4);
            String author = args.get(5);
            String description = String.join(" ", args.subList(6, args.size())).replace("\\n", "\n");

            String text = MessageFormat.format("info=\"1\"\n" +
                    "\n" +
                    "name=\"{0}\"\n" +
                    "id=\"{1}\"\n" +
                    "version=\"{2}\"\n" +
                    "mcversion=\"{3}\"\n" +
                    "\n" +
                    "main=\"{4}\"\n" +
                    "\n" +
                    "author=\"{5}\"\n" +
                    "description=\"\"\"\n" +
                    "{6}\n" +
                    "\"\"\"\n", name, id, version, mcversion, main, author, description);

            try (Writer writer = new OutputStreamWriter(new FileOutputStream(new File(Main.dir, "info.toml")), StandardCharsets.UTF_8);) {
                writer.write(text);
            } catch (Exception e) {
                e.printStackTrace();
                messager.send("写入文件时发生异常");
            }

        } else {
            messager.send("参数不够");
        }
    }

    @Override
    public List<String> complete(List<String> args) {
        if (args.size() == 1) {
            return Literals.stringListBuilder().adds("Example");
        }
        if (args.size() == 2) {
            return Literals.stringListBuilder().adds("example");
        }
        if (args.size() == 3) {
            return Literals.stringListBuilder().adds("1.0", "1.1", "1.2");
        }
        if (args.size() == 4) {
            return Literals.stringListBuilder().adds("all", "1.8.9", "1.12.2", "1.16.5", "1.20.0");
        }
        if (args.size() == 5) {
            return Literals.stringListBuilder().adds("Main", "org.example.Main");
        }
        if (args.size() == 6) {
            return Literals.stringListBuilder().adds("steve");
        }
        if (args.size() == 7) {
            return Literals.stringListBuilder().adds("这是一个示例项目");
        }
        return Literals.emptyComplete();
    }

    @Override
    public List<? extends FormatHandler> format(List<String> args) {
        return Literals.emptyFormat();
    }

    @Override
    public InfoHandler info(List<String> args) {
        if (args.size() == 0) {
            return Literals.infoFactory().string("构建info.toml");
        }
        if (args.size() == 1) {
            return Literals.infoFactory().string("name");
        }
        if (args.size() == 2) {
            return Literals.infoFactory().string("id");
        }
        if (args.size() == 3) {
            return Literals.infoFactory().string("version");
        }
        if (args.size() == 4) {
            return Literals.infoFactory().string("mcversion");
        }
        if (args.size() == 5) {
            return Literals.infoFactory().string("main");
        }
        if (args.size() == 6) {
            return Literals.infoFactory().string("author");
        }
        if (args.size() >= 7) {
            return Literals.infoFactory().string("description");
        }
        return Literals.emptyInfo();
    }
}