package com.artedprvt.initializer.java.goals;

import com.artedprvt.initializer.java.FileTool;
import com.artedprvt.initializer.java.Main;
import com.artedprvt.initializer.java.phases.PhaseCompile;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.work.ClassByteTool;
import com.artedprvt.work.anno.Goal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Goal(PhaseCompile.class)
public class GoalCompile implements ProcessInterface, InfoHandler {
    public GoalCompile() {

    }

    @Override
    public void process(List<String> list, Messager messager) {
        messager.send("编译");

        List<File> javaFiles = FileTool.getAllFile(Main.src_java);
        Map<String, String> sourceMap = new HashMap<>();

        for (File javaFile : javaFiles) {
            String path = FileTool.relativize(Main.src_java, javaFile);

            StringBuilder sb = new StringBuilder();
            int n;
            try (Reader reader = new InputStreamReader(new FileInputStream(javaFile), StandardCharsets.UTF_8)) {
                while ((n = reader.read()) != -1) {
                    sb.append((char) n);
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            sourceMap.put(path, sb.toString());
        }

        Map<String, byte[]> classMap;
        try {
            classMap = ClassByteTool.compile(sourceMap);
        } catch (Exception e) {
            messager.send("编译失败: " + e.getMessage());
            throw new RuntimeException(e);
        }

        for (String className : classMap.keySet()) {
            String path = className.replace('.', '/') + ".class";

            File file = new File(Main.out_classes, path);
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try (OutputStream output = new FileOutputStream(file)) {
                output.write(classMap.get(className));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        messager.send("编译成功 (" + classMap.size() + " 个class)");
    }

    @Override
    public String handleInfo(String s) {
        return "编译";
    }
}