package com.artedprvt.initializer.java;

public class Property {
    public static final String artifactName = "app";
}
