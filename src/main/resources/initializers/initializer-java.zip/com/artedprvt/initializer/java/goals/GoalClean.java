package com.artedprvt.initializer.java.goals;

import com.artedprvt.initializer.java.FileTool;
import com.artedprvt.initializer.java.Main;
import com.artedprvt.initializer.java.phases.PhaseClean;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.work.anno.Goal;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@Goal(PhaseClean.class)
public class GoalClean implements ProcessInterface, InfoHandler {
    public GoalClean() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        List<File> files = new ArrayList<>();
        files.addAll(FileTool.getAllFile(Main.out));
        files.forEach(File::delete);

        messager.send("清理");
    }

    @Override
    public String handleInfo(String source) {
        return "清理";
    }
}