package com.artedprvt.initializer.java.goals;

import com.artedprvt.initializer.java.FileTool;
import com.artedprvt.initializer.java.Main;
import com.artedprvt.initializer.java.Property;
import com.artedprvt.initializer.java.phases.PhasePackage;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.work.anno.Goal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Goal(PhasePackage.class)
public class GoalPackage implements ProcessInterface, InfoHandler {
    public GoalPackage() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        Map<String, File> map = new HashMap<>();
        for (File f : FileTool.getAllFile(Main.out_classes)) {
            map.put(FileTool.relativize(Main.out_classes, f), f);
        }
        for (File f : FileTool.getAllFile(Main.src_resources)) {
            map.put(FileTool.relativize(Main.src_resources, f), f);
        }
        map.put("info.toml", new File(Main.dir, "info.toml"));

        try {
            File target = new File(Main.out_app, Property.artifactName + ".jar");
            target.createNewFile();
            ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(target));

            for (String name : map.keySet()) {
                ZipEntry entry = new ZipEntry(name);
                zip.putNextEntry(entry);
                InputStream input = new FileInputStream(map.get(name));
                int n;
                while (true) {
                    if ((n = input.read()) == -1) {
                        break;
                    }
                    zip.write(n);
                }
                zip.closeEntry();
            }
            zip.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        messager.send("打包");
    }

    @Override
    public String handleInfo(String source) {
        return "打包";
    }
}