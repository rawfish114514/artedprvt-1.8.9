package com.artedprvt.initializer.java;

import com.artedprvt.work.ProjectAccess;
import com.artedprvt.work.ProjectSystem;
import com.artedprvt.work.anno.Initializer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;

@Initializer(
        name = "Artedprvt Java Project",
        description = "使用Java构建用于APF的应用程序",
        author = "APF")
public class Main implements ProjectAccess {
    public static ProjectSystem projectSystem = null;
    public static File dir = null;
    public static File src = null;
    public static File src_java = null;
    public static File src_resources = null;
    public static File out = null;
    public static File out_classes = null;
    public static File out_app = null;

    @Override
    public void main(ProjectSystem projectSystem) {
        Main.projectSystem = projectSystem;
        dir = new File(projectSystem.getDir());
        (src = new File(dir, "src")).mkdir();
        (src_java = new File(src, "java")).mkdir();
        (src_resources = new File(src, "resources")).mkdir();
        (out = new File(dir, "out")).mkdir();
        (out_classes = new File(out, "classes")).mkdir();
        (out_app = new File(out, "app")).mkdir();

        try (Writer writer = new OutputStreamWriter(new FileOutputStream(new File(dir, "readme.txt")), StandardCharsets.UTF_8)) {
            writer.write(
                    "如果你使用 IDEA\n" +
                            "" +
                            "用IDEA打开此项目\n" +
                            "设置jdk版本\n" +
                            "将lib.jar和lib-source.jar一起添加到库\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
