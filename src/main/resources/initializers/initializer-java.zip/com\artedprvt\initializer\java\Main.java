package com.artedprvt.initializer.java;

import com.artedprvt.std.minecraft.chat.ChatConsole;
import com.artedprvt.std.text.Formatting;
import com.artedprvt.work.ProjectAccess;
import com.artedprvt.work.ProjectSystem;
import com.artedprvt.work.anno.Initializer;

import java.io.File;

@Initializer(
        name = "Artedprvt Java Project",
        description = "使用Java构建用于APF的应用程序",
        author = "APF")
public class Main implements ProjectAccess {
    public static ProjectSystem projectSystem = null;
    public static File dir = null;
    public static File src = null;
    public static File src_java = null;
    public static File src_resources = null;
    public static File out = null;
    public static File out_classes = null;
    public static File out_app = null;

    @Override
    public void main(ProjectSystem projectSystem) {
        Main.projectSystem = projectSystem;
        dir = new File(projectSystem.getDir());
        (src = new File(dir, "src")).mkdir();
        (src_java = new File(src, "java")).mkdir();
        (src_resources = new File(src, "resources")).mkdir();
        (out = new File(dir, "out")).mkdir();
        (out_classes = new File(out, "classes")).mkdir();
        (out_app = new File(out, "app")).mkdir();

        ChatConsole console = new ChatConsole();
        if (new File(dir, "artedprvt-4.0.jar").isFile() || new File(dir, "artedprvt-4.0-sources.jar").isFile()) {

        } else {
            console.print(Formatting.GOLD + "没有 artedprvt-4.0.jar 或 artedprvt-4.0-sources.jar");
            console.print(Formatting.GOLD + "请在官网下载 前者是模组本体 后者是模组源码");
            console.print(Formatting.GOLD + "将这两个文件放入项目目录下在IDEA中选中右键->添加为库");
        }
    }
}
