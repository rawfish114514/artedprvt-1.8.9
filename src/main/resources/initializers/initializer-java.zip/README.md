## 填写项目名称

---

描述:这是项目的描述文件模板，编写此文件供其他开发者或用户了解此项目。

## 安装

---

选择一种

* [从发行中下载](https://github.com/your-name/your-repository/releases)
* [去应用中下载](https://artedprvt.com/apps/your-app)


* 执行此命令
> /install your-app

如果你选择前两种，那么你需要手动安装程序包。

## 开发

---

打开项目
> /project open [path]

初始化项目
> /project init java

加载项目
> /project load

编译打包安装后运行
> /work install
> 
> /app app.jar

## 作者

---

your

other

## 许可证

---

...