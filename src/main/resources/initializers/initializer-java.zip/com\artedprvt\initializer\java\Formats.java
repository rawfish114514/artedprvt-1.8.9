package com.artedprvt.initializer.java;

import com.artedprvt.std.cli.FormatHandler;
import com.artedprvt.std.cli.util.Literals;

import java.util.regex.Pattern;

public class Formats {

    public static FormatHandler phaseFormatHandler = Literals.formatFactory().regex(
            Pattern.compile("(?<phase>[a-z]*(_[a-z]*)*)"),
            "§?phase",
            Literals.formatMapBuilder()
                    .puts("phase", Literals.formatFactory().append("a")),
            Literals.formatFactory().append("4")
    );

    public static FormatHandler goalFormatHandler = Literals.formatFactory().regex(
            Pattern.compile("(?<phase>[a-z]*(_[a-z]*)*)(?<pro>:)(?<goal>[a-z]*(_[a-z]*)*)"),
            "§?phase§?pro§?goal",
            Literals.formatMapBuilder()
                    .puts("phase", Literals.formatFactory().append("a"))
                    .puts("pro", Literals.formatFactory().append("7"))
                    .puts("goal", Literals.formatFactory().append("b")),
            Literals.formatFactory().append("4")
    );

    public static FormatHandler commandFormatHandler = Literals.formatFactory().regex(
            Pattern.compile("(?<command>[a-z]*(_[a-z]*)*)"),
            "§?command",
            Literals.formatMapBuilder()
                    .puts("command", Literals.formatFactory().append("d")),
            Literals.formatFactory().append("4")
    );
}