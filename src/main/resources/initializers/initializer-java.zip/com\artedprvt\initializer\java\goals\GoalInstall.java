package com.artedprvt.initializer.java.goals;

import com.artedprvt.core.app.Home;
import com.artedprvt.initializer.java.Main;
import com.artedprvt.initializer.java.Property;
import com.artedprvt.initializer.java.phases.PhaseInstall;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.work.anno.Goal;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

@Goal(PhaseInstall.class)
public class GoalInstall implements ProcessInterface, InfoHandler {
    public GoalInstall() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        File source = new File(Main.out_app, Property.artifactName + ".jar");
        File target = new File(Home.app(), Property.artifactName + ".jar");
        if (source.isFile()) {
            try {
                target.createNewFile();
                OutputStream out = new FileOutputStream(target);
                InputStream in = new FileInputStream(source);
                int n = 0;
                while ((n = in.read()) != -1) {
                    out.write(n);
                }
                out.close();
                in.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        messager.send("安装");
    }

    @Override
    public String handleInfo(String source) {
        return "安装";
    }
}