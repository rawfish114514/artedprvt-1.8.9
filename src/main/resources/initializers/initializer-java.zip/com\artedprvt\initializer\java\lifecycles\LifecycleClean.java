package com.artedprvt.initializer.java.lifecycles;

import com.artedprvt.initializer.java.phases.PhaseClean;
import com.artedprvt.work.anno.Lifecycle;

@Lifecycle({
        PhaseClean.class
})
public class LifecycleClean {
}
