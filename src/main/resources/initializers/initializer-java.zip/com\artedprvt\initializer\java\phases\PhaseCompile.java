package com.artedprvt.initializer.java.phases;

import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.work.anno.Phase;

@Phase
public class PhaseCompile implements InfoHandler {
    public PhaseCompile() {

    }

    @Override
    public String handleInfo(String source) {
        return "编译阶段";
    }
}