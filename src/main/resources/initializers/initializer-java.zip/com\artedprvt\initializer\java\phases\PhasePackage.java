package com.artedprvt.initializer.java.phases;

import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.work.anno.Phase;

@Phase
public class PhasePackage implements InfoHandler {
    public PhasePackage() {

    }

    @Override
    public String handleInfo(String source) {
        return "打包阶段";
    }
}