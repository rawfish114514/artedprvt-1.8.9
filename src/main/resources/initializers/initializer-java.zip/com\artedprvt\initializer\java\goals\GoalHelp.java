package com.artedprvt.initializer.java.goals;

import com.artedprvt.initializer.java.Formats;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.work.anno.Goal;
import com.artedprvt.initializer.java.Property;

import java.util.List;

@Goal
public class GoalHelp implements ProcessInterface, InfoHandler {
    public GoalHelp() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        messager.send(Formats.phaseFormatHandler.handleFormat("clean"), "清理阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("clean:clean"), "清理阶段的清理目标，清除out目录的所有文件");
        messager.send(Formats.phaseFormatHandler.handleFormat("compile"), "编译阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("compile:compile"), "编译阶段的编译目标，将src目录的java文件编译为class文件输出到out/classes目录");
        messager.send(Formats.phaseFormatHandler.handleFormat("package"), "打包阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("package:package"), "打包阶段的打包目标，将src/resources目录的文件和out/classes的文件打包成jar文件并输出到out目录");
        messager.send(Formats.phaseFormatHandler.handleFormat("install"), "安装阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("install:install"), "安装阶段的安装目标，将out/app目录的" + Property.artifactName + ".jar文件复制到home的app目录");
        messager.send(Formats.commandFormatHandler.handleFormat("build_info"), "命令，构建info.toml表单文件");
    }

    @Override
    public String handleInfo(String source) {
        return "帮助";
    }
}