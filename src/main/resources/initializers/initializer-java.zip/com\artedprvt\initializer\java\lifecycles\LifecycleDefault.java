package com.artedprvt.initializer.java.lifecycles;

import com.artedprvt.initializer.java.phases.PhaseCompile;
import com.artedprvt.initializer.java.phases.PhaseInstall;
import com.artedprvt.initializer.java.phases.PhasePackage;
import com.artedprvt.work.anno.Lifecycle;

@Lifecycle({
        PhaseCompile.class,
        PhasePackage.class,
        PhaseInstall.class,
})
public class LifecycleDefault {
}
