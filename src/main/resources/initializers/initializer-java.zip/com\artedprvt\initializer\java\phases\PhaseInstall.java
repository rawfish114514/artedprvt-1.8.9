package com.artedprvt.initializer.java.phases;

import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.work.anno.Phase;

@Phase
public class PhaseInstall implements InfoHandler {
    public PhaseInstall() {

    }

    @Override
    public String handleInfo(String source) {
        return "安装阶段";
    }
}