/* This source code is distributed with APF under the MIT license. */

package com.artedprvt.work._0;

import com.artedprvt.core.app.Home;
import com.artedprvt.std.cli.CompleteInterface;
import com.artedprvt.std.cli.FormatHandler;
import com.artedprvt.std.cli.FormatInterface;
import com.artedprvt.std.cli.InfoHandler;
import com.artedprvt.std.cli.InfoInterface;
import com.artedprvt.std.cli.Messager;
import com.artedprvt.std.cli.ProcessInterface;
import com.artedprvt.std.cli.util.Literals;
import com.artedprvt.work.ProjectAccess;
import com.artedprvt.work.ProjectSystem;
import com.artedprvt.work.anno.Command;
import com.artedprvt.work.anno.Goal;
import com.artedprvt.work.anno.Lifecycle;
import com.artedprvt.work.anno.Phase;
import com.artedprvt.work.anno.ProjectScript;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

class Property {
    public static final String artifactName = "my_app";
}

@ProjectScript(
        name = "Artedprvt Script Project",
        description = "用于APF的script应用程序的项目脚本",
        created = "APF"
)
public class ap implements ProjectAccess {
    public static ProjectSystem projectSystem = null;
    public static File dir = null;
    public static File src = null;
    public static File src_script = null;
    public static File src_assets = null;
    public static File out = null;
    public static File out_app = null;

    @Override
    public void main(ProjectSystem projectSystem) {
        ap.projectSystem = projectSystem;
        dir = new File(projectSystem.getDir());
        (src = new File(dir, "src")).mkdir();
        (src_script = new File(src, "script")).mkdir();
        (src_assets = new File(src, "assets")).mkdir();
        (out = new File(dir, "out")).mkdir();
        (out_app = new File(out, "app")).mkdir();
    }
}


@Phase
class PhaseClean implements InfoHandler {
    public PhaseClean() {

    }

    @Override
    public String handleInfo(String source) {
        return "清理阶段";
    }
}

@Phase
class PhaseCompile implements InfoHandler {
    public PhaseCompile() {

    }

    @Override
    public String handleInfo(String source) {
        return "编译阶段";
    }
}

@Phase
class PhasePackage implements InfoHandler {
    public PhasePackage() {

    }

    @Override
    public String handleInfo(String source) {
        return "打包阶段";
    }
}

@Phase
class PhaseInstall implements InfoHandler {
    public PhaseInstall() {

    }

    @Override
    public String handleInfo(String source) {
        return "安装阶段";
    }
}


@Lifecycle({
        PhaseClean.class
})
class LifecycleClean {
}

@Lifecycle({
        PhaseCompile.class,
        PhasePackage.class,
        PhaseInstall.class,
})
class LifecycleDefault {
}

@Goal(PhaseClean.class)
class GoalClean implements ProcessInterface, InfoHandler {
    public GoalClean() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        List<File> files = new ArrayList<>();
        files.addAll(FileTool.getAllFile(ap.out));
        files.forEach(File::delete);

        messager.send("清理");
    }

    @Override
    public String handleInfo(String source) {
        return "清理";
    }
}

@Goal(PhasePackage.class)
class GoalPackage implements ProcessInterface, InfoHandler {
    public GoalPackage() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        Map<String, File> map = new HashMap<>();
        for (File f : FileTool.getAllFile(ap.src_script)) {
            map.put(FileTool.relativize(ap.src, f), f);
        }
        for (File f : FileTool.getAllFile(ap.src_assets)) {
            map.put(FileTool.relativize(ap.src, f), f);
        }
        map.put("info.toml", new File(ap.dir, "info.toml"));

        try {
            File target = new File(ap.out_app, Property.artifactName + ".asp");
            target.createNewFile();
            ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(target));

            for (String name : map.keySet()) {
                ZipEntry entry = new ZipEntry(name);
                zip.putNextEntry(entry);
                InputStream input = new FileInputStream(map.get(name));
                int n;
                while (true) {
                    if ((n = input.read()) == -1) {
                        break;
                    }
                    zip.write(n);
                }
                zip.closeEntry();
            }
            zip.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        messager.send("打包");
    }

    @Override
    public String handleInfo(String source) {
        return "打包";
    }
}

@Goal(PhaseInstall.class)
class GoalInstall implements ProcessInterface, InfoHandler {
    public GoalInstall() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        File source = new File(ap.out_app, Property.artifactName + ".asp");
        File target = new File(Home.app(), Property.artifactName + ".asp");
        if (source.isFile()) {
            try {
                target.createNewFile();
                OutputStream out = new FileOutputStream(target);
                InputStream in = new FileInputStream(source);
                int n = 0;
                while ((n = in.read()) != -1) {
                    out.write(n);
                }
                out.close();
                in.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        messager.send("安装");
    }

    @Override
    public String handleInfo(String source) {
        return "安装";
    }
}

@Goal
class GoalHelp implements ProcessInterface, InfoHandler {
    public GoalHelp() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        messager.send(Formats.phaseFormatHandler.handleFormat("clean"), "清理阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("clean:clean"), "清理阶段的清理目标，清除out目录的所有文件");
        messager.send(Formats.phaseFormatHandler.handleFormat("package"), "打包阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("package:package"), "打包阶段的打包目标，将src目录的文件打包成asp文件并输出到out/app目录");
        messager.send(Formats.phaseFormatHandler.handleFormat("install"), "安装阶段");
        messager.send("  " + Formats.goalFormatHandler.handleFormat("install:install"), "安装阶段的安装目标，将out/app目录的" + Property.artifactName + ".asp文件复制到home的app目录");
        messager.send(Formats.commandFormatHandler.handleFormat("build_info"), "命令，构建info.toml表单文件");
    }

    @Override
    public String handleInfo(String source) {
        return "帮助";
    }
}

@Command
class CommandBuildInfo implements ProcessInterface, CompleteInterface, FormatInterface, InfoInterface {
    public CommandBuildInfo() {

    }

    @Override
    public void process(List<String> args, Messager messager) {
        if (args.size() >= 7) {
            String name = args.get(0);
            String id = args.get(1);
            String version = args.get(2);
            String mcversion = args.get(3);
            String module = args.get(4);
            String author = args.get(5);
            String description = String.join(" ", args.subList(6, args.size())).replace("\\n", "\n");

            String text = MessageFormat.format("info=\"1\"\n" +
                    "\n" +
                    "name=\"{0}\"\n" +
                    "id=\"{1}\"\n" +
                    "version=\"{2}\"\n" +
                    "mcversion=\"{3}\"\n" +
                    "\n" +
                    "module=\"{4}\"\n" +
                    "\n" +
                    "author=\"{5}\"\n" +
                    "description=\"\"\"\n" +
                    "{6}\n" +
                    "\"\"\"\n", name, id, version, mcversion, module, author, description);

            try (Writer writer = new OutputStreamWriter(new FileOutputStream(new File(ap.dir, "info.toml")), StandardCharsets.UTF_8);) {
                writer.write(text);
            } catch (Exception e) {
                e.printStackTrace();
                messager.send("写入文件时发生异常");
            }

        } else {
            messager.send("参数不够");
        }
    }

    @Override
    public List<String> complete(List<String> args) {
        if (args.size() == 1) {
            return Literals.stringListBuilder().adds("Example");
        }
        if (args.size() == 2) {
            return Literals.stringListBuilder().adds("example");
        }
        if (args.size() == 3) {
            return Literals.stringListBuilder().adds("1.0", "1.1", "1.2");
        }
        if (args.size() == 4) {
            return Literals.stringListBuilder().adds("all", "1.8.9", "1.12.2", "1.16.5", "1.20.0");
        }
        if (args.size() == 5) {
            return Literals.stringListBuilder().adds("main", "js:main");
        }
        if (args.size() == 6) {
            return Literals.stringListBuilder().adds("steve");
        }
        if (args.size() == 7) {
            return Literals.stringListBuilder().adds("这是一个示例项目");
        }
        return Literals.emptyComplete();
    }

    @Override
    public List<? extends FormatHandler> format(List<String> args) {
        return Literals.emptyFormat();
    }

    @Override
    public InfoHandler info(List<String> args) {
        if (args.size() == 0) {
            return Literals.infoFactory().string("构建info.toml");
        }
        if (args.size() == 1) {
            return Literals.infoFactory().string("name");
        }
        if (args.size() == 2) {
            return Literals.infoFactory().string("id");
        }
        if (args.size() == 3) {
            return Literals.infoFactory().string("version");
        }
        if (args.size() == 4) {
            return Literals.infoFactory().string("mcversion");
        }
        if (args.size() == 5) {
            return Literals.infoFactory().string("module");
        }
        if (args.size() == 6) {
            return Literals.infoFactory().string("author");
        }
        if (args.size() >= 7) {
            return Literals.infoFactory().string("description");
        }
        return Literals.emptyInfo();
    }
}

class Formats {

    public static FormatHandler phaseFormatHandler = Literals.formatFactory().regex(
            Pattern.compile("(?<phase>[a-z]*(_[a-z]*)*)"),
            "§?phase",
            Literals.formatMapBuilder()
                    .puts("phase", Literals.formatFactory().append("a")),
            Literals.formatFactory().append("4")
    );

    public static FormatHandler goalFormatHandler = Literals.formatFactory().regex(
            Pattern.compile("(?<phase>[a-z]*(_[a-z]*)*)(?<pro>:)(?<goal>[a-z]*(_[a-z]*)*)"),
            "§?phase§?pro§?goal",
            Literals.formatMapBuilder()
                    .puts("phase", Literals.formatFactory().append("a"))
                    .puts("pro", Literals.formatFactory().append("7"))
                    .puts("goal", Literals.formatFactory().append("b")),
            Literals.formatFactory().append("4")
    );

    public static FormatHandler commandFormatHandler = Literals.formatFactory().regex(
            Pattern.compile("(?<command>[a-z]*(_[a-z]*)*)"),
            "§?command",
            Literals.formatMapBuilder()
                    .puts("command", Literals.formatFactory().append("d")),
            Literals.formatFactory().append("4")
    );
}

class FileTool {
    public static List<File> getAllFile(File file) {
        List<File> files = new ArrayList<>();
        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                files.addAll(getAllFile(f));
            }
        } else {
            files.add(file);
        }
        return files;
    }

    public static String relativize(File base, File full) {
        return base.toPath().relativize(full.toPath()).toString().replace(File.separatorChar, '/');
    }
}
