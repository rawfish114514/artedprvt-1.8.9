/**
 * Hello Minecraft!
 * Created by Rawfishc on 2023/8/7
 */
import("*mi");
import("-net.minecraft.init.Items");
import("-net.minecraft.item.ItemStack");
import("-rawfish.artedprvt.id.Local");

var path=props().get("frame.dir").replace("\\","/")+"/src/script/main.js";

if(args()[0]=="114514"){
    import("-java.awt.Desktop");
    import("-java.io.File");
    var directory = new File(new File(path).getParent());
    if(Desktop.isDesktopSupported()){
        var desktop = Desktop.getDesktop();
        try {
            desktop.open(directory);
        } catch (e) {
            print("访问失败");
        }
    }else{
        print("不支持Desktop");
    }
    exit(0);
}

var lang=Local.getLanguage();
var out=print;
out("           §4__§3_");
out("          §4/ / §3\\§l §r        §f__");
out("         §4/ / §3\\ \\        §f|  |");
out("        §4/ /   §3\\ \\       §f|__|");
out("       §4/ /-----§3\\ \\§l §r     §f__");
out("      §4/ /-------§3\\ \\     §f|  |");
out("     §4/ /         §3\\ \\    §f|_ |");
out("    §4/_/           §3\\_\\   §f_|_|");


var client=new GameClient();
var server=new GameServer();

var player=server.getPlayer(server.getWorld(0),client.getPlayer().getName());

if(lang=="zh_cn"){
    var tag=TagBuilder.compound()
        .setString("title","Hello Minecraft")
        .setString("author","Rawfishc")
        .setList("pages",TagBuilder.list()
            .addString("{text:'§4Arted§3prvt §rFrame 简称:APF\n\n这个脚本首先打印出这个模组的Logo，然后编辑这样的一本书送到你的背包里。这个脚本就在\n\n',extra:[{text:'"+path+"',color:dark_green,clickEvent:{action:run_command,value:'/script js:main 114514'}}]}")
        )
        .build();

    var item=new ItemStack(Items.written_book);
    item.setTagCompound(tag);

    player.inventory.addItemStackToInventory(item);
}


