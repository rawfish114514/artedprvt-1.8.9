function complete(args,Literals){
	if(core.language=="zh_cn"){
		return ["参数补全"];
	}
	return ["complete"];
}

function format(args,Literals){
	return ["bo"];
}

function info(args,Literals){
	if(core.language=="zh_cn"){
		return "参数补全测试";
	}
	return "info";
}